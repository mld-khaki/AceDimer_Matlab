function Out = ACD_Contribution_Lookup_Prv_Accuracy_v2p0p2(InpAllCombinations,InpVect,Reset)
persistent AllCombs

if Reset == 1
    AllCombs = struct;
    
    for iCtr=1:size(InpAllCombinations,1)
        tmp = iCtr;
        Vect = ConvertToList(InpAllCombinations(iCtr,:));
        for jCtr=size(InpAllCombinations,2):-1:2
            newTmp = struct;
            newTmp = tmp.(Vect{jCtr});
        end
        
        AllCombs.(Vect{1}) = tmp;
    end
    
    return
else
    Out = MLD_NDimLUT_Read(AllCombs,ConvertToList(sort(InpVect)));
    
end

end

function Vect = ConvertToList(Inp)
Vect = {};
for qCtr=1:length(Inp)
    Vect{qCtr} = sprintf('M%04u',Inp(qCtr));
end
end
% SelVect = ones(1,size(InpAllCombinations,1),'logical');
% InpVect = sort(InpVect);
% for qCtr=1:length(InpVect)
%     Vect2 = (InpAllCombinations(:,qCtr) ~= InpVect(qCtr));
%
%     SelVect(Vect2) = 0;
% end
%
% Out = [];
%
% if nansum(SelVect) >= 1
%     Out = find(SelVect);
% end


% for qCtr=1:size(InpAllCombinations,1)
%     Found = 1;
%     for iCtr=1:length(InpVect)
%         if Found == 0, continue;end
%         if InpAllCombinations(qCtr,iCtr) > InpVect(iCtr)
%             Found = 0;
%             break;
%         end
%         if sum(InpAllCombinations(qCtr,:) == InpVect(iCtr)) ~= 1
%             Found = 0;
%             break;
%         end
%     end
%     if Found == 1
%         Out = qCtr;
%         return
%     end
% end
% end


%Second version
% function Out = ACD_Contribution_Lookup_Prv_Accuracy(InpAllCombinations,InpVect)
% Out = [];
% % AllCombs = perms(InpVect);
% % OrgVect = 1:size(InpAllCombinations,1);
%
% for qCtr=1:size(InpAllCombinations,1)
%     Found = 1;
%     for iCtr=1:length(InpVect)
%         if Found == 0, continue;end
%         if sum(InpAllCombinations(qCtr,:) == InpVect(iCtr)) ~= 1
%             Found = 0;
%             continue;
%         end
%     end
%     if Found == 1
%         Out = qCtr;
%         return
%     end
% end
% end
%


% OrgVersion
%
% function Out = ACD_Contribution_Lookup_Prv_Accuracy(InpAllCombinations,InpVect)
% AllCombs = perms(InpVect);
% OrgVect = 1:size(InpAllCombinations,1);
%
% for qCtr=1:size(AllCombs,1)
%     tmpVect = AllCombs(qCtr,:);
%     Vect = OrgVect;
%     for iCtr=1:length(tmpVect)
%         Vect2 = find(InpAllCombinations(Vect,iCtr) == tmpVect(iCtr));
%         Vect = Vect(Vect2);
%     end
%     if ~isempty(Vect)
%         Out = Vect;
%         return
%     end
% end
% end