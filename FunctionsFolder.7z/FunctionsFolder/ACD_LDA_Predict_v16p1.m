function PredictedClasses = ACD_LDA_Predict_v16p1(LDA_Model,Inputs)

L = [ones(size(Inputs,1),1) Inputs] * LDA_Model.Weights';

P = exp(L) ./ repmat(sum(exp(L),2),[1 length(LDA_Model.ClassLabels)]);

[~,PredictedClasses] = nanmax(P');

PredictedClasses = LDA_Model.ClassLabels(PredictedClasses);

end





