function Out = ACD_If(Condition,TrueStatement,FalseStatement)
if Condition 
	Out = TrueStatement;
else
	Out = FalseStatement;
end
end